package com.example.materialdesign;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
  private DrawerLayout mDrawerLayout;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolBar);
    setSupportActionBar(toolbar);
    mDrawerLayout = findViewById(R.id.drawable_layout);
    ActionBar actionBar = getSupportActionBar();
    if(actionBar!=null){
      actionBar.setDisplayHomeAsUpEnabled(true);
      actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
    }
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.toolbar,menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    switch (item.getItemId()){
      case R.id.back_up:
        Toast.makeText(this,"You clicked BackUp option",Toast.LENGTH_SHORT).show();
        break;
      case R.id.delete:
        Toast.makeText(this,"You clicked Delete option",Toast.LENGTH_SHORT).show();
        break;
      case R.id.settings:
        Toast.makeText(this,"You clicked Settings option",Toast.LENGTH_SHORT).show();
        break;
      case android.R.id.home:
        mDrawerLayout.openDrawer(GravityCompat.START);
        break;
      default:
    }
    return true;
  }
}